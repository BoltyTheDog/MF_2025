import numpy as np
import matplotlib.pyplot as plt
import os

#Paràmetres
U = 1.0  
a = 1.0  
Gamma = 2 * np.pi  
grid_size = 500  
x_range = 5.0  
rho = 1.0  

# Punts de la "grid"
x = np.linspace(-x_range, x_range, grid_size)
y = np.linspace(-x_range, x_range, grid_size)
X, Y = np.meshgrid(x, y)

# Conversió a coordenades polars
R = np.sqrt(X**2 + Y**2)
Theta = np.arctan2(Y, X)

# Cuidado amb dividir entre 0 a l'origen
R[R < 1e-10] = 1e-10

# Stream function al voltant del cilindre rodannt
psi = U * (R - a**2 / R) * np.sin(Theta) - (Gamma / (2 * np.pi)) * np.log(R)

# Àerea dins el cilindre
psi[R < a] = np.nan

# Components velocitat (u, v) coordenades cartesianes
# Analytical velocity components with circulation
u = U * (1 - a**2 / R**2 * np.cos(2 * Theta)) + (Gamma / (2 * np.pi)) * (-Y / (R**2))
v = -U * a**2 / R**2 * np.sin(2 * Theta) + (Gamma / (2 * np.pi)) * (X / (R**2))

# V dins el cilindre
u[R < a] = np.nan
v[R < a] = np.nan

# Magnitud velocitat
V_mag = np.sqrt(u**2 + v**2)

# Pressure field (Bernoulli)
P_inf = 0.0
P = P_inf + 0.5 * rho * (U**2 - V_mag**2)

# Pressió dins el cilindre
P[R < a] = np.nan

# Crear carpeta
output_dir = "output"
if not os.path.exists(output_dir):
    os.makedirs(output_dir)

# Stream Function (Contour)
plt.figure(figsize=(6, 6))
plt.contour(X, Y, psi, levels=50, colors='blue')
circle = plt.Circle((0, 0), a, color='black', fill=True)
plt.gca().add_patch(circle)
plt.title("Stream Function")
plt.xlabel("x")
plt.ylabel("y")
plt.axis('equal')
plt.savefig(os.path.join(output_dir, 'stream_function.png'))
plt.close()

# Velocity Magnitude (Filled Contour)
plt.figure(figsize=(6, 6))
plt.contourf(X, Y, V_mag, levels=50, cmap='viridis')
circle = plt.Circle((0, 0), a, color='black', fill=True)
plt.gca().add_patch(circle)
plt.colorbar(label="Velocity Magnitude")
plt.title("Velocity Magnitude")
plt.xlabel("x")
plt.ylabel("y")
plt.axis('equal')
plt.savefig(os.path.join(output_dir, 'velocity_magnitude.png'))
plt.close()

# Pressure Field (Filled Contour)
plt.figure(figsize=(6, 6))
plt.contourf(X, Y, P, levels=50, cmap='RdBu_r')
circle = plt.Circle((0, 0), a, color='black', fill=True)
plt.gca().add_patch(circle)
plt.colorbar(label="Pressure Field")
plt.title("Pressure Field")
plt.xlabel("x")
plt.ylabel("y")
plt.axis('equal')
plt.savefig(os.path.join(output_dir, 'pressure_field.png'))
plt.close()

# Velocity Field (Quiver)
plt.figure(figsize=(6, 6))
plt.quiver(X[::10, ::10], Y[::10, ::10], u[::10, ::10], v[::10, ::10], color='green', scale=50)  # Increased subsampling and scale for clarity
circle = plt.Circle((0, 0), a, color='black', fill=True)
plt.gca().add_patch(circle)
plt.title("Velocity Field")
plt.xlabel("x")
plt.ylabel("y")
plt.axis('equal')
plt.savefig(os.path.join(output_dir, 'velocity_field.png'))
plt.close()